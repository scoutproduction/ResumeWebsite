# Castady Labs — Illustrated Essay Edition

Open `index.html` directly in a browser or publish it to GitHub Pages. This is a standalone static file, including the portrait and original ImagineWeb figure. No installation, API keys, model service, or external dependencies are required.

## Essays
Six illustrated adaptations of the manuscripts supplied by Michael Castady. The reader provides the original manuscript text, section navigation, font-size controls, a glossary, conceptual diagrams, an interactive thought experiment, and shareable deep links (`#essay-imagineweb`, `#essay-internet`, `#essay-ontology`, `#essay-symbol`, `#essay-assonance`, `#essay-software-ai`). All experiments are browser-based conceptual illustrations, not trained models or empirical studies. The original manuscripts include draft passages and references; review before publishing. No unrelated contents from the uploaded archive are included.

## Publish
Replace the existing `index.html` in the root of your GitHub Pages repository, commit it, and push. In Settings → Pages select your publishing branch and root directory. If you do not own a custom domain, leave Custom domain empty.

## Customize
The HTML contains CSS, data, and JavaScript. Find `const essays=` for essay content and `essayDemos` for experiment implementations. The previous projects, research, laboratory, skills, experience, and résumé remain in place.
